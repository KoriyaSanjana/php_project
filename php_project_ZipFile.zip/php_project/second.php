<?php
session_start();

// Connect to the database
$db = mysqli_connect('localhost', 'root', '', 'project');

// Check if the user has submitted the login form
if (isset($_POST['login_user'])) {
    $name = mysqli_real_escape_string($db, $_POST['username']);
    $password = mysqli_real_escape_string($db, $_POST['password']);

    // Query the database for the user
    $query = "SELECT * FROM project_user WHERE username='$name' AND pwd='$password'";
    $results = mysqli_query($db, $query);

    // If the user exists, set the session variables and redirect to the index page
    if (mysqli_num_rows($results) == 1) {
        $_SESSION['username'] = $username;
        $_SESSION['success'] = "You have logged in!";
        header('location: home_page.html');
    } else {
        // If the user doesn't exist, display an error message
        echo "Username or password incorrect";
    }
}
?>