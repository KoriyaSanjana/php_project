<?php

/*$username= "root";
$servername="localhost";
$password="";
$database= "connect_to_oracle";
$conn = mysqli_connect($servername,$username,$password,$database);

$sql = "CREATE TABLE `changes` (`sno` INT(6) NOT NULL AUTO_INCREMENT , `Name` VARCHAR(16) NOT NULL , `Password` INT(8) NOT NULL,`pno` INT(10) NOT NULL,`gmail_id` VARCHAR(12),
PRIMARY KEY (`sno`))";
$result = mysqli_query($conn,$sql);

?>
*/
$sql="CREATE TABLE `recipe` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(50) NOT NULL,
    `mobile` VARCHAR(20) NOT NULL,
    `email` VARCHAR(50) NOT NULL,
    `gender` VARCHAR(10) NOT NULL,
    `birthdate` DATE NOT NULL,
    `username` VARCHAR(50) NOT NULL,
    `password` VARCHAR(50) NOT NULL
)";
$result = mysqli_query($conn,$sql);
?>
