<?php
/*$username= "root";
$servername="localhost";
$password="";
$conn = mysqli_connect($servername,$username,$password);
if(!$conn)
    {
        die("sorry we failed to connect :" .mysqli_connect_error());
    }
else {
    echo "successfully connected";
}

 $sql = "CREATE DATABASE connect_to_oracle";
$result= mysqli_query($conn, $sql);
echo var_dump($result);
 

?>