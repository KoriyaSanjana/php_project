
</html>
<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
<style>
.container {
    width: 300px;
    background-color: #f2f2f2;
    padding: 20px;
    margin: 0 auto;
    margin-top: 100px;
    border: 1px solid #ddd;
    border-radius: 5px;
  background-image: url('https://flawless.life/wp-content/uploads/2020/06/foody-farm-classy-burger.jpg');
  background-size: cover;
  background-position: center;
}



.container h2 {
    text-align: center;
    margin-bottom: 20px;
}

.container label {
    display: block;
    margin-bottom: 5px;
}

.container input[type="text"],
.container input[type="password"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.container button[type="submit"] {
    width: 100%;
    padding: 10px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.container button[type="submit"]:hover {
    background-color: #45a049;
}
</style>
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <form action="second.php" method="post">
            <label for="username" style="color :white"><h3>Username:</h3></label>
            <input type="text" id="username" name="username" required>
            <label for="password" style="color :white"><h3>Password:</h3></label>
            <input type="password" id="password" name="password" required>
            <button type="submit" name="login_user">Login</button>
            
        </form>
    </div>
</body>
</html>