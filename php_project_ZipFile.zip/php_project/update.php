<?php
session_start();



$name = $_POST['name'];
$o_pwd = $_POST['o_password'];
$n_pwd = $_POST['n_password'];
$check=0;
$db = mysqli_connect('localhost', 'root', '', 'project');

if (isset($_POST['login_user'])) {
    $name = mysqli_real_escape_string($db, $_POST['name']);
    $o_pwd = mysqli_real_escape_string($db, $_POST['o_password']);

    // Query the database for the user
    $query = "SELECT * FROM project_user WHERE username='$name' AND pwd='$o_pwd'";
    $results = mysqli_query($db, $query);

    // If the user exists, set the session variables and redirect to the index page
    if (mysqli_num_rows($results) == 1) {
       $check=1;

    } else {
        // If the user doesn't exist, display an error message
        echo "Username or password incorrect";

    }
}

// Create connection
// Check connection
if($check==1){
$sql = "UPDATE project_user SET pwd=$n_pwd WHERE username='$name'";

if ($db->query($sql) === TRUE) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . $db->error;
}
}

mysqli_close($db);
?>

