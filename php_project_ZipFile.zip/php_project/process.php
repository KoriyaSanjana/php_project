<?php
$name = $_POST['name'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$gender = $_POST['gender'];
$birthdate = $_POST['birthdate'];
$passworde = $_POST['password'];

if (empty($name) || empty($passworde)) {
	echo "Username and password are required.";
	exit();
}

// Connect to the database
$conn = mysqli_connect('localhost', 'root', '', 'project');

if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
// Insert the form data into the database
$sql = "INSERT INTO project_user VALUES ('','$name','$mobile', '$email', '$gender','$birthdate', '$passworde')";

if (mysqli_query($conn, $sql)) {
	echo "New record created successfully";

} else {
	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>