<?php
$name = $_POST['name'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$gender = $_POST['gender'];
$birthdate = $_POST['birthdate'];
$password = $_POST['password'];

echo"$password";
// Validate the form data
if (empty($name) || empty($mobile) || empty($email) || empty($gender) || empty($birthdate) || empty($password)) {
	echo "All fields are required.";
	echo'<a href="page1.html"> must fill this form </a>';
	exit();
}

// Connect to the database


// Redirect to the second page
//header("Location: process.php");
?>
<html>
<body>
	<form action="process.php" method="post">
		<input type="text" name="name" value="<?php echo $name; ?>">
    <input type="text" name="email" value="<?php echo $email; ?>">
    <input type="text" name="mobile" value="<?php echo $mobile; ?>">
    <input type="text" name="gender" value="<?php echo $gender; ?>">
    <input type="text" name="birthdate" value="<?php echo $birthdate; ?>">
    <input type="text" name="password" value="<?php echo $password; ?>">
<input type="submit">


	</form>
</body>
</html>

