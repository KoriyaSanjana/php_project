<html>
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Document</title>
    <style>
        body{
            padding: 0;
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #383838;
        }
        .box{
            height: 100px;
            width: 290px;
            display: flex;
            justify-content: space-around;
            align-items: center;
        }
        button{
            height: 100px;
            width: 250px;
            border: none;
            outline: none;
            font-size: 20px;
            font-weight: 700;
        }
        button,.fa{
            color: #383838;
            box-shadow: 3px 3px 6px rgba(0, 0, 0, 0.5);
            cursor: pointer;
        }
        .fa{
            font-size: 80px;
            padding: 10px 18px;
        }
        #back,.fa-mail-forward{
            border-top-right-radius: 300px;
            border-bottom-right-radius: 300px;
        }
        #next{
            border-top-left-radius: 200px;
            border-bottom-left-radius: 200px;
        }
       
        .fa-mail-forward{
            background: linear-gradient(#ffeb3b,#ff5722);
        }
    </style>
</head>


<?php
  $ans=$_GET['recipe'];

  switch ($ans) {
    case 'pasta':
     echo '<html><body><div class="box"> 
		<a href="next_pre.html"><button id="next">PASTA</button></a>
		<i class="fa fa-mail-forward" ></i>
		</body></html>
		';
      break;

    case 'vada-pav':
      echo '<html><body><div class="box">  
		<a href="next_pre1.html"><button id="next">VADA-PAV</button></a>
		<i class="fa fa-mail-forward" ></i>
		</body></html>
		';
       break;
    
    case 'okra':
      echo '<html><body><div class="box">
		<a href="next_pre2.html"><button id="next">OKRA</button></a>
		<i class="fa fa-mail-forward" ></i>
		</body></html>
		';
      break;

      case 'paratha':
      echo '<html><body><div class="box">     
		<a href="next_pre3.html"><button id="next">ALOO-PARATHA</button></a>
		<i class="fa fa-mail-forward" ></i>
		</body></html>
		';
      break;
    default:
      echo "Invalid grade.";
  }
?>
 </html>








 